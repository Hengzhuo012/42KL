/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: swei-khu <swei-khu@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/11 15:42:32 by swei-khu          #+#    #+#             */
/*   Updated: 2026/06/13 11:36:43 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#include <stdio.h>

void	print_numbers(void)
{
	int		num;
	char	c;

	num = 0;
	while (num <= 9)
	{
		c = '0' + num;
		num++;
		write (1, &c, 1);
	}
}

int	main(void)
{
	print_numbers();
	return (0);
}
