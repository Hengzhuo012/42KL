/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: swei-khu <swei-khu@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/11 18:42:54 by swei-khu          #+#    #+#             */
/*   Updated: 2026/06/13 11:37:35 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#include <stdio.h>

void	ft_is_negative(int n)
{
	char	c;

	if (n > 0)
	{
		c = 'P';
		write (1, &c, 1);
	}
	else
	{
		c = 'N';
		write (1, &c, 1);
	}
}

int	main(void)
{
	ft_is_negative(5);
	ft_is_negative(-4);
	ft_is_negative(3);
	return (0);
}
