/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 17:57:16 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:49:59 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	if (nb == 0 || nb == 1)
		return (0);
	if (nb == 2)
		return (1);
	while (i < nb)
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;
	int	n2;
	int	n3;

	n = 2;
	n2 = 8;
	n3 = 11;
	printf("Is %d prime? %d\n", n, ft_is_prime(n));
	printf("Is %d prime? %d\n", n2, ft_is_prime(n2));
	printf("Is %d prime? %d\n", n3, ft_is_prime(n3));
}
*/
