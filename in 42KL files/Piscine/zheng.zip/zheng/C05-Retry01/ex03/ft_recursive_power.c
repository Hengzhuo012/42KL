/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 17:35:51 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:49:16 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	if (power == 1)
		return (nb);
	return (nb * ft_recursive_power(nb, power - 1));
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;
	int	p;

	n = 5;
	p = 3;
	printf("%d ^ %d = %d", n, p, ft_recursive_power(n, p));
}
*/
