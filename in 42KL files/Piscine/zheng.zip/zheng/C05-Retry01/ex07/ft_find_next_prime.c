/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 18:13:11 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:50:15 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_find_next_prime(int nb)
{
	int	i;
	int	check;
	int	next_prime;

	if (nb <= 2)
		return (2);
	check = 0;
	next_prime = nb;
	while (check == 0)
	{
		check = 1;
		i = 2;
		while (i < next_prime)
		{
			if (next_prime % i == 0)
				check = 0;
			i++;
		}
		if (check == 0)
			next_prime++;
	}
	return (next_prime);
}

/*
#include <stdio.h>
int	main(void)
{
	int	n1;
	int	n2;
	int	n3;

	n1 = 1;
	n2 = 95;
	n3 = 97;
	printf("%d next prime is %d\n", n1, ft_find_next_prime(n1));
        printf("%d next prime is %d\n", n2, ft_find_next_prime(n2));
	printf("%d next prime is %d\n", n3, ft_find_next_prime(n3));
}
*/
