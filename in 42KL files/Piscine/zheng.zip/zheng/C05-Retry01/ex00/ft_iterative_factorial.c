/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:43:39 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:41:34 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	i;
	int	number;

	number = 1;
	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	else
	{
		if (nb >= 0)
		{
			i = nb;
			while (i >= 1)
				number *= i--;
			return (number);
		}
	}
	return (0);
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;

	n = 0;
	printf("factorial of %d is %d", n, ft_iterative_factorial(n));
}
*/
