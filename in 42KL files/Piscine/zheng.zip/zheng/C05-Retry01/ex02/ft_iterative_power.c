/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:54:57 by zheng             #+#    #+#             */
/*   Updated: 2026/06/29 10:31:41 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	number;

	number = 1;
	if (power < 0)
		return (0);
	while (power > 0)
	{
		number *= nb;
		power--;
	}
	return (number);
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;
	int	p;

	n = 5;
	p = 0;
	printf("%d ^ %d = %d", n, p, ft_iterative_power(n, p));
}
*/
