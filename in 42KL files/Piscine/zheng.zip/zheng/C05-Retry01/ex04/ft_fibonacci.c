/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 17:40:11 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:49:30 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_fibonacci(int index)
{
	if (index < 0)
		return (-1);
	if (index == 0)
		return (0);
	if (index == 1)
		return (1);
	return (ft_fibonacci(index - 1) + ft_fibonacci(index - 2));
}

/*
#include <stdio.h>
int	main(void)
{
	printf("%d\n", ft_fibonacci(9));
}
*/

// 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 45, 89, 134
// 0, 1, 2, 3, 4, 5, 6,  7,  8,  9, 10, 11,  12
