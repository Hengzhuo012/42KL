/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:54:57 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:48:46 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	number;

	number = 1;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	else
	{
		i = 1;
		while (i++ <= power)
			number *= nb;
		return (number);
	}
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;
	int	p;

	n = 0;
	p = 5;
	printf("%d ^ %d = %d", n, p, ft_iterative_power(n, p));
}
*/
