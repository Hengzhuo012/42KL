/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:50:25 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:47:47 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	if (nb < 0)
		return (0);
	if (nb > 1)
		return (nb * ft_recursive_factorial(nb - 1));
	if (nb == 1 || nb == 0)
		return (1);
	return (0);
}

/*
#include <stdio.h>
int	main(void)
{
	int	n;

	n = 6;
	printf("%d! = %d", n, ft_recursive_factorial(n));
}
*/
