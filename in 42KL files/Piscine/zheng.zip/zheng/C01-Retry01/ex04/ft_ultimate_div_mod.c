/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 13:49:10 by zheng             #+#    #+#             */
/*   Updated: 2026/06/15 11:34:42 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	c;

	c = *a;
	*a = c / *b;
	*b = c % *b;
}

/*
int	main(void)
{
	int	x;
	int	y;
	
	x = 5;
	y = 2;
	printf("Before, x:%d, y:%d\n", x, y);
	ft_ultimate_div_mod(&x, &y);
	printf("After, x:%d, y:%d\n", x, y);
}
*/
