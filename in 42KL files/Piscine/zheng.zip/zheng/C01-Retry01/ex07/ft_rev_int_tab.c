/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 14:31:37 by zheng             #+#    #+#             */
/*   Updated: 2026/06/13 14:53:19 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	temp;

	i = 0;
	temp = 0;
	while (i != size / 2)
	{
		temp = tab[i];
		tab[i] = tab[size - i - 1];
		tab[size - i - 1] = temp;
		i++;
	}
}

/*
int	main(void)
{
	int	test[] = {1, 4, 5};
	int	i;
	char	c;
	ft_rev_int_tab(&test[0], 3);
	i = 0;
	while (i <= 2)
	{
		c = test[i] + '0';
		write(1, &c, 1);
		i++;
	}
}
*/
