/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 14:53:57 by zheng             #+#    #+#             */
/*   Updated: 2026/06/13 15:22:07 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	swap;
	int	temp;

	i = 0;
	swap = 1;
	temp = 0;
	while (swap == 1)
	{
		swap = 0;
		i = 0;
		while (i < size - 1)
		{
			if (tab[i] > tab[i + 1])
			{
				temp = tab[i];
				tab[i] = tab[i + 1];
				tab[i + 1] = temp;
				swap = 1;
			}
			i++;
		}
		size--;
	}
}

/*
int	main(void)
{
	int	test[] = {1, 3, 9, 5, 6};
	int	i;
	char	c;

	i = 0;
	ft_sort_int_tab(&test[0], 5);
	while (i <= 4)
	{
		c = test[i] + '0';
		write(1, &c, 1);
		i++;
	}
}
*/
