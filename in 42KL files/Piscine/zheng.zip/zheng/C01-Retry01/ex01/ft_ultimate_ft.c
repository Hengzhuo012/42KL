/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 10:51:00 by zheng             #+#    #+#             */
/*   Updated: 2026/06/13 10:58:44 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

/*
int	main(void)
{
	int	a;
	char	tens;
	char	ones;
	
	// Declaring the 9 levels of pointers
	int	*ptr1;
	int	**ptr2;
	int	***ptr3;
	int	****ptr4;
	int	*****ptr5;
	int	******ptr6;
	int	*******ptr7;
	int	********ptr8;
	int	*********ptr9;

	a = 5;

	// Pointing each level to the next one down the chain
	ptr1 = &a;
	ptr2 = &ptr1;
	ptr3 = &ptr2;
	ptr4 = &ptr3;
	ptr5 = &ptr4;
	ptr6 = &ptr5;
	ptr7 = &ptr6;
	ptr8 = &ptr7;
	ptr9 = &ptr8;

	// Modify 'a' through the pointer chain
	ft_ultimate_ft(ptr9);
	
	// 'a' is now 42. Let's convert it to characters to use write().
	tens = (a / 10) + '0'; // 42 / 10 = 4 -> '4'
	ones = (a % 10) + '0'; // 42 % 10 = 2 -> '2'

	// Print the digits and a newline
	write(1, &tens, 1);
	write(1, &ones, 1);
	write(1, "\n", 1);
	
	return (0);
}
*/
