/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 13:46:10 by zheng             #+#    #+#             */
/*   Updated: 2026/06/13 13:48:28 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

/*
int	main(void)
{
	int	x;
	int	y;
	int	a;
	int	b;
	
	x = 5;
	y = 2;
	ft_div_mod(x, y, &a, &b);
	printf("2 numbers, x:%d, y:%d\n Div: %d, Mod: %d", x, y, a, b);
}
*/
