/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 10:15:30 by zheng             #+#    #+#             */
/*   Updated: 2026/06/21 17:44:48 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

//size is size of array
void	ft_print(char *array, int size)
{
	int	i;

	i = 0;
	while (i < size * size)
	{
		write(1, &array[i], 1);
		if (i % size != size - 1)
			write(1, " ", 1);
		else
			write(1, "\n", 1);
		i++;
	}
}

void	ft_error(void)
{
	write(1, "Error\n", 5);
}

void	ft_error_size(void)
{
	write(1, "Invalid size\n", 13);
}

void	ft_error_inputs(void)
{
	write(1, "argc != 2", 9);
}
