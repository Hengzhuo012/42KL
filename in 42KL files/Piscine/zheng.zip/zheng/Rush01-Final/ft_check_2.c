/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/21 14:24:26 by zheng             #+#    #+#             */
/*   Updated: 2026/06/21 17:17:45 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//Check if elements in the row matches with the elements in same col
//Return 0 if matches, 1 if is unique
int	ft_col_check(char *array, int size, int row)
{
	int	col;
	int	i_row;

	col = 0;
	while (col < size)
	{
		i_row = row - size + col;
		while (i_row >= 0)
		{
			if (array[i_row] == array[row + col])
				return (0);
			i_row -= size;
		}
		col++;
	}
	return (1);
}
