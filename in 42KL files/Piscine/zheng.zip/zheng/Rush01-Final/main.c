/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 15:10:31 by zheng             #+#    #+#             */
/*   Updated: 2026/06/21 18:55:32 by ochong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void	ft_error(void);
void	ft_error_size(void);
void	ft_error_inputs(void);
void	ft_print(char *array, int size);
int		ft_create(char *array, int size, char **argv);

/*
Calculate the size of array
Example input for size of 4 have length 31
So we need to +1 and sqrt it
Return Sqrt value or 0 if no value found
*/
int	ft_size(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	if ((len + 1) % 8 != 0)
		return (0);
	return ((len + 1) / 8);
}

//array is 1D array that stores 16 bits, 1st 4 in row1, 2nd 4 in row2...
int	main(int argc, char **argv)
{
	char	*array;
	int		size_of_array;
	int		check;
	int		i;

	if (argc == 2)
	{
		size_of_array = ft_size(argv[1]);
		if (size_of_array != 0)
		{
			array = malloc((size_of_array * size_of_array + 1) * sizeof(char));
			i = 0;
			while (i < (size_of_array * size_of_array))
			{
				array[i] = '0';
				i++;
			}
			array[i] = '\0';
			check = ft_create(array, size_of_array, argv);
			if (check == 0)
				ft_error();
			else
				ft_print(array, size_of_array);
			free(array);
		}
		else
			ft_error_size();
	}
	else
		ft_error_inputs();
}
