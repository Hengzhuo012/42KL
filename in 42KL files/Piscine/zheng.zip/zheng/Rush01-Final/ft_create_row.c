/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_row.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 16:36:26 by zheng             #+#    #+#             */
/*   Updated: 2026/06/22 16:17:39 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

//from ft_next_value.c
void	ft_next_permutation(char *out, int size);
//return 1 if true, else 0
int		ft_not_last_comb(char *str_row, int size);
//from ft_check.c, return 1 if passes, else 0
int		ft_diff_check_row(char *str_row, int size, char **argv, int row);
int		ft_diff_check_col(char *array, int size, char **argv);
int		ft_col_check(char *array, int size, int row);

//set all elements in the row to 0
void	ft_reset_row(char *array, int size, int row)
{
	int	i;

	i = row;
	while (i < row + size)
	{
		array[i] = '0';
		i++;
	}
}

//set row to "1234"
void	ft_initialise_row(char *array, int size, int row)
{
	int	i;

	i = 0;
	while (i < size)
	{
		array[row + i] = '1' + i;
		i++;
	}
}

//next value until pass col check or reached last combination
//return 0 if last combination, 1 if success
int	ft_next_value(char *array, int size, int row, char *str_row)
{
	int	check;
	int	i;

	check = 0;
	while (check == 0)
	{
		if (ft_not_last_comb(str_row, size) == 0)
			return (0);
		ft_next_permutation(str_row, size);
		i = 0;
		while (i < size)
		{
			array[row + i] = str_row[i];
			i++;
		}
		if (row != 0)
			check = ft_col_check(array, size, row);
		else
			check = 1;
	}
	return (1);
}

/*
array is a string
size is size of array
row is the 1st element of the row need to be next value eg, 0, 4, 8, 12
**argv is the input from main function

return 0 if no solution, 1 if row created

i to loop each col in row
check to store value from ft_diff_check_row
str_row to store the values in the row

if array[row] == '0' means no value is in it, initialise to "1234"
*/
int	ft_create_row(char *array, int size, int row, char **argv)
{
	char	*str_row;
	int		check;
	int		i;

	check = 0;
	str_row = malloc((size + 1) * sizeof(char));
	while (check == 0)
	{
		i = 0;
		while (i < size)
		{
			str_row[i] = array[row + i];
			i++;
		}
		str_row[size] = '\0';
		if (ft_not_last_comb(str_row, size) == 0)
		{
			if (row == 0)
			{
				free(str_row);
				return (0);
			}
			ft_reset_row(array, size, row);
			row -= size;
			check = 0;
		}
		else
		{
			if (array[row] == '0')
			{
				ft_initialise_row(array, size, row);
				i = 0;
				while (i < size)
				{
					str_row[i] = array[row + i];
					i++;
				}
				str_row[size] = '\0';
				check = ft_col_check(array, size, row);
			}
			else
				check = ft_next_value(array, size, row, str_row);
			if (check == 1)
			{
				check = ft_diff_check_row(str_row, size, argv, row);
			}
		}
		if (check == 1 && row == size * (size - 1))
			check = ft_diff_check_col(array, size, argv);
	}
	return (1);
}

int	ft_create(char *array, int size, char **argv)
{
	int	row;
	int	check;

	row = 0;
	while (row <= size * (size - 1))
	{
		check = ft_create_row(array, size, row, argv);
		if (check == 0)
			return (0);
		row += size;
	}
	return (1);
}
