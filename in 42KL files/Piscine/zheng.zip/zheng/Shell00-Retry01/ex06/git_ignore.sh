git status --ignored | find .. -type f -exec basename {} \;
