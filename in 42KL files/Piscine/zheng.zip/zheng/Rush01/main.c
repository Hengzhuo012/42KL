/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 15:10:31 by zheng             #+#    #+#             */
/*   Updated: 2026/06/20 17:11:12 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

//array is 1D array that stores 16 bits, 1st 4 in row1, 2nd 4 in row2...

int	main(int agrc, char **argv)
{
	int	size_of_array;
	char	*array;

	array = malloc((size_of_array * size_of_array) * sizeof(char));
}
