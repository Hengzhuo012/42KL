/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_row.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 16:36:26 by zheng             #+#    #+#             */
/*   Updated: 2026/06/20 17:49:58 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//from ft_next_value.c
void    ft_next_permutation(char *out, int size);
//return 1 if true, else 0
int     ft_not_last_comb(char *str, int size)

//from ft_check.c, return 1 if passes, else 0
int     ft_diff_check(char *str, int front_input, int back_input, int size_array);

//set all elements in the row to 0
void	ft_initialise_row(char *array, int size, int row)
{
	int	i;

	i = row;
	while (i < row + size)
	{
		array[i] = '0';
		i++;
	}
}


/*
array is a string
size is size of array
row is the 1st element of the row need to be next value eg, 0, 4, 8, 12
**argv is the input from main function

return 0 if it is not possible, 1 if row created

i to loop each col in row
check to store value from ft_diff_check
row_str to store the values in the row

what the function does ?
- store values in row in row_str
- check if it is last combination
- no, next permutataion
- yes, check if is 1st row
- no, initialise current row, go to prev row
- yes, return 0
- repeat until the combination passes the left right and element on top check

if array[row] == '0' means no value is in it, initialise to "1234"
*/
int	ft_create_row(char *array, int size, int row, char **argv)
{
	int	i;
	int	check;
	int	left_input;
	int	right_input;
	char	*row_str;

	i = 0;
	check = 0;
	if (array[row] == '0')
	{
		while (i < size)
		{
			array[row + i] = '1' + i;
			i++;
		}
	}
	else
	{
		row_str = malloc(size * sizeof(char));
		while (check == 0)
		{
			i = 0;
			while (i < size)
			{
				row_str[i] = array[row + i];
				i++;
			}
			if (ft_not_last_comb(row_str, size) == 1)
				ft_next_permutation(row_str, size);
				left_input = ((row / size) * 2) + (2 * (size + size));
				right_input = ((row / size) * 2) + (2 * (size + size)); 
				check = ft_diff_check(row_str, left_input, right_input, size); //add the element on top check here

			else
			{
				if (row == 0)
				{
					free(row_str);
					return (0);
				}
				ft_initialise_row(array, size, row);
				row -= size;
				check = 0;
			}
		}
		free(row_str);
	}
	return (0);
}
