/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 14:58:23 by zheng             #+#    #+#             */
/*   Updated: 2026/06/20 17:18:54 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//used for ft_diff_check to count the diff value from front and back
//if you have idea to combine both, pls do
int	ft_front(char *str, char *largest, int size_array, int i)
{
	int	diff;

	diff = 1;
	while (i < size_array)
	{
		if (str[i] > str[i - 1])
		{
			largest = str[i];
			diff += 1;
		}
		i++;
	}
	return (diff);
}

int	ft_back(char *str, char *largest, int size_array, int i)
{
	int	diff;

	diff = 1;
	while (i < size_array)
	{
		if (str[size_array - 1 - i] > str[size_array - i])
		{
			largest = str[size_array - 1 - i];
			diff += 1;
		}
		i++;
	}
	return (diff);
}

/*
check if matches the input, if passes return 1 else 0
str is the value to be test like "1234"
front_input is where it counts from i = 0
size_of_array is 4 for base question, up to 9 for bonus

if row, front and back are left and right
if col, front and back are top and bottom
*/
int	ft_diff_check(char *str, int front_input, int back_input, int size_array)
{
	int	largest_front;
	int	largest_back;
	int	diff_front;
	int	diff_back;

	largest_front = str[0];
	largest_back = str[size_array - 1];
	diff_front = ft_front(str, largest_front, size_array, 1);
	diff_back = ft_back(str, largest_back, size_array);
	if (diff_front == front_input && diff_back == back_input)
		return (1);
	return (0);
}
