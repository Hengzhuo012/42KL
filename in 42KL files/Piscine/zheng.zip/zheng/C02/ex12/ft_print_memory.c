/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/16 12:39:42 by zheng             #+#    #+#             */
/*   Updated: 2026/06/22 10:24:53 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_hexadecimal(char *str)
{
	char	*hexa;

	hexa = "0123456789abcdef";
	write(1, &hexa[*str / 16], 1);
	write(1, &hexa[*str % 16], 1);
}

void	ft_print_addr(void *addr)
{
	int	i;

	i = 0;
	while (i <= 7)
	{
		ft_hexadecimal(&addr[i]);
		i++;
	}
	write(1, ": ", 2);
}

int	ft_non_printable(char c)
{
	int	i;
	int	to_be_returned;

	i = 0;
	to_be_returned = 0;
	if (c < ' ' || c == 127)
		to_be_returned = 1;
	return (to_be_returned);
}

void	ft_print_content(char *addr)
{
	int	i;

	i = 0;
	while (i != 15)
	{
		if (addr[i] != '\0')
			ft_hexadecimal(&addr[i]);
		else
			write(1, "  ", 2);
		if (i % 2 == 1 || i == 14)
			write(1, " ", 1);
		i++;
	}
	i = 0;
	while (addr[i] != '\0')
	{
		if (ft_non_printable(addr[i]) == 1)
			write(1, ".", 1);
		else
			write(1, &addr[i], 1);
		i++;
	}
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	int	i;

	if (size != 0)
	{
		ft_print_addr(addr);
		ft_print_content(addr);
	}
	return (0);
}

/*
int	main(void)
{
	char	*str = "Hello W\1rld!";
	int	size = 0;

	while (str[size])
		size++;
	ft_print_memory(str, size);
}
*/
