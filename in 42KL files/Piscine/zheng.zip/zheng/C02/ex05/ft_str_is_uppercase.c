/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/15 13:42:35 by zheng             #+#    #+#             */
/*   Updated: 2026/06/15 13:50:26 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;
	int	to_be_returned;

	i = 0;
	to_be_returned = 1;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
			to_be_returned = 0;
		i++;
	}
	return (to_be_returned);
}

/*
int	main(void)
{
	char lower[] = "test";
	char upper[] = "TeSt";
	printf("Lower file is %d", ft_str_is_uppercase(&lower[0]));
	printf("Upper file is %d", ft_str_is_uppercase(&upper[0]));
}
*/
