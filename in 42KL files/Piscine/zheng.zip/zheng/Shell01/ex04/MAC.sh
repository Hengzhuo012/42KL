ifconfig | grep ether | cut -c-31 | cut -c 15-
