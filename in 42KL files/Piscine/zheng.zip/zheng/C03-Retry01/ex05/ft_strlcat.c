/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 12:55:29 by zheng             #+#    #+#             */
/*   Updated: 2026/06/25 16:58:29 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_length(char *src)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	dest_len;
	unsigned int	src_len;

	i = 0;
	dest_len = 0;
	src_len = ft_length(src);
	while (dest[dest_len] != '\0')
		dest_len++;
	if (dest_len >= size)
		return (size + src_len);
	while (src[i] != '\0' && (dest_len + i) < (size - 1))
	{
		dest[i + dest_len] = src[i];
		i++;
	}
	dest[i + dest_len] = '\0';
	return (dest_len + src_len);
}

#include <stdio.h>
int	main(void)
{
	char	src[] = "letters";
	char	dest[] = "random\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
	int	n = 6;
	printf("src: %s\nLength returned: %d\n", src, ft_strlcat(dest, src, n));
	printf("dest: %s\n", dest);
}
