/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/16 11:11:47 by zheng             #+#    #+#             */
/*   Updated: 2026/06/24 13:24:39 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	ft_strlowcase(str);
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			if (i == 0)
				str[i] = str[i] - 32;
			else
			{
				if (!(str[i - 1] >= 'a' && str[i - 1] <= 'z'))
				{
					if (!(str[i - 1] >= 'A' && str[i - 1] <= 'Z'))
					{
						if (!(str[i - 1] >= '0' && str[i - 1] <= '9'))
							str[i] = str[i] - 32;
					}
				}
			}
		}
		i++;
	}
	return (str);
}

/*
#include <stdio.h>
int	main(void)
{
	char	test[] = "hi, how are you? 42words forty-two; fifty+and+one";
	
	printf("Before: %s\n", test);
	printf("After: %s\n", ft_strcapitalize(test));
}
*/
