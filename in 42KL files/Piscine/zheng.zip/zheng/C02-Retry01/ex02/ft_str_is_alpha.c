/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/15 13:16:41 by zheng             #+#    #+#             */
/*   Updated: 2026/06/15 13:48:55 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;
	int	to_be_returned;

	i = 0;
	to_be_returned = 1;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			if (!(str[i] >= 'A' && str[i] <= 'Z'))
				to_be_returned = 0;
		}
		i++;
	}
	return (to_be_returned);
}

/*
int	main(void)
{
	char src[] = "Source";
	char num[] = "123";
	printf("Source file is %d", ft_str_is_alpha(&src[0]));
	printf("Number file is %d", ft_str_is_alpha(&num[0]));
}
*/
