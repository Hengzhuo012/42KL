/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/15 13:42:35 by zheng             #+#    #+#             */
/*   Updated: 2026/06/15 13:48:16 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;
	int	to_be_returned;

	i = 0;
	to_be_returned = 1;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
			to_be_returned = 0;
		i++;
	}
	return (to_be_returned);
}

/*
int	main(void)
{
	char lower[] = "test";
	char upper[] = "TeSt";
	printf("Lower file is %d", ft_str_is_lowercase(&lower[0]));
	printf("Upper file is %d", ft_str_is_lowercase(&upper[0]));
}
*/
