/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/16 12:22:44 by zheng             #+#    #+#             */
/*   Updated: 2026/06/24 13:32:43 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_hexadecimal(unsigned char c)
{
	char	*hexa;

	hexa = "0123456789abcdef";
	ft_putchar(hexa[c / 16]);
	ft_putchar(hexa[c % 16]);
}

void	ft_putstr_non_printable(char *str)
{
	unsigned char	uc;
	int				i;

	i = 0;
	while (str[i])
	{
		uc = (unsigned char)str[i];
		if (uc < ' ' || uc == 127)
		{
			ft_putchar('\\');
			ft_hexadecimal(uc);
		}
		else
			ft_putchar(str[i]);
		i++;
	}
}

/*
int	main(void)
{
	char	*str = "Line1\nLine2";

	ft_putstr_non_printable(str);
}
*/
