/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/15 13:50:56 by zheng             #+#    #+#             */
/*   Updated: 2026/06/16 11:02:31 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	to_be_returned;
	int	i;

	i = 0;
	to_be_returned = 1;
	while (str[i] != '\0')
	{
		if (!(str[i] >= ' ' && str[i] <= '~'))
			to_be_returned = 0;
		i++;
	}
	return (to_be_returned);
}

//ASCII 32th to 126th is printable, which are ' ' and '~' resp.

/*
int	main(void)
{
	char	*str1 = "test123!@#$;";
	char	*str2 = "±";
	
	printf("Is %s printable? %d\n", str1, ft_str_is_printable(str1));	
	printf("Is %s printable? %d\n", str2, ft_str_is_printable(str2));
}
*/
