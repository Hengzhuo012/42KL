/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/13 13:06:57 by zheng             #+#    #+#             */
/*   Updated: 2026/06/13 13:07:32 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

static void	print_pair(int i, int j)
{
	char	a1;
	char	a2;
	char	b1;
	char	b2;

	a1 = (i / 10) + '0';
	a2 = (i % 10) + '0';
	b1 = (j / 10) + '0';
	b2 = (j % 10) + '0';
	write(1, &a1, 1);
	write(1, &a2, 1);
	write(1, " ", 1);
	write(1, &b1, 1);
	write(1, &b2, 1);
	if (!(i == 98 && j == 99))
		write(1, ", ", 2);
}

void	ft_print_comb2(void)
{
	int	i;
	int	j;

	i = 0;
	while (i <= 98)
	{
		j = i + 1;
		while (j <= 99)
		{
			print_pair(i, j);
			j++;
		}
		i++;
	}
}

int	main(void)
{
	ft_print_comb2();
}
