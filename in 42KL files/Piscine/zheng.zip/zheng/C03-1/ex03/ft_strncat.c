/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 11:10:49 by zheng             #+#    #+#             */
/*   Updated: 2026/06/18 11:50:19 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int	dest_len;
	int	src_len;
	int	i;

	dest_len = ft_strlen(dest);
	src_len = ft_strlen(src);
	i = dest_len;
	while (i <= dest_len + src_len && i - dest_len <= nb - 1)
	{
		dest[i] = src[i - dest_len];
		i++;
	}
	if (src_len < nb)
		dest[i] = '\0';
	return (dest);
}

/*
int	main(void)
{
	char dest[] = "Test\0\0\0\0\0\0\0";
	char src[] = "randoms";

	printf("Before: %s\n", dest);
	printf("After: %s", ft_strncat(dest, src, 5));
}
*/
