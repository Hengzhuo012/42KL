/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 10:41:55 by zheng             #+#    #+#             */
/*   Updated: 2026/06/18 11:06:19 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_ascii_sum(char *s, unsigned int n)
{
	int	i;
	int	sum;

	i = 0;
	sum = 0;
	while (s[i] != '\0' && i <= n - 1)
	{
		sum += s[i];
		i++;
	}
	return (sum);
}

int	ft_strcmp(char *s1, char *s2, unsigned int n)
{
	int	sum1;
	int	sum2;

	sum1 = ft_ascii_sum(s1, n);
	sum2 = ft_ascii_sum(s2, n);
	if (sum1 == sum2)
		return (0);
	else
		return (sum1 - sum2);
}

/*
int	main(void)
{
	char	s1[] = "Test";
	char	s2[] = "Test2";

	printf("%d", ft_strcmp(s1, s2, 3));
}
*/
