/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 12:55:29 by zheng             #+#    #+#             */
/*   Updated: 2026/06/18 13:06:10 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

unsigned int	ft_length(char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	int	i;
	int	dest_len;

	i = 0;
	dest_len = ft_length(dest);
	if (size > 0)
	{
		while (src[i] != '\0' && i < size - 1)
		{
			dest[i + dest_len] = src[i];
			i++;
		}
		dest[i + dest_len] = '\0';
	}
	return (dest_len + ft_length(src));
}

/*
int	main(void)
{
	char	src[] = "letters";
	char	dest[] = "random\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
	int	n = 6;
	printf("src: %s\nLength returned: %d\n", src, ft_strlcat(dest, src, n));
	printf("dest: %s\n", dest);
}
*/
