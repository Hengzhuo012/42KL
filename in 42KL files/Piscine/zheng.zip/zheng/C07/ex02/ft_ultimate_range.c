/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 12:30:42 by zheng             #+#    #+#             */
/*   Updated: 2026/06/29 15:39:36 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

/*
unsigned int	ft_set_size(unsigned int size, int min, int max)
{
	if (min >= 0 && max > 0)
		size = (unsigned int)max - (unsigned int)min;
	if (min < 0 && max >= 0)
	{
		if (min == -2147483648)
			size = (unsigned int)max + 2147483648;
		else
		{
			min *= (-1);
			size = (unsigned int)max + (unsigned int)min;
		}
	}
	if (min < 0 && max < 0)
	{
		max *= (-1);
		if (min == -214783648)
			size = 2147483648 - (unsigned int)max;
		else
		{
			min *= (-1);
			size = (unsigned int)min - (unsigned int)max;
		}
	}
	return (size);
}
*/

int	ft_ultimate_range(int **range, int min, int max)
{
	int				*array;
	unsigned int	size;
	unsigned int	n;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	size = (unsigned int)max - (unsigned int)min;
	array = malloc(size * sizeof(int));
	if (array == NULL)
		return (-1);
	*range = array;
	n = 0;
	while (n < size)
	{
		array[n] = n + min;
		n++;
	}
	return (size);
}

/*
#include <stdio.h>
int	main(void)
{
	int	min;
	int	max;
	int	*array;
	int	size;

	min = -9;
	max = 9;
	size = ft_ultimate_range(&array, min, max);
	printf("Size: %d\n", size);
	while (size > 0)
	{
		printf("%d\n", array[size - 1]);
		size--;
	}
	free(array);
}
*/
