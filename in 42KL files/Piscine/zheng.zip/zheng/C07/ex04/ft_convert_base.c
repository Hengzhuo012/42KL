/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/24 09:46:28 by zheng             #+#    #+#             */
/*   Updated: 2026/06/29 15:03:18 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_len(char *str);
int		ft_is_base_valid(char *base);
char	*ft_atoi_number(char *nbr, char *base_from,
			int nbr_counter, char *new_nbr);
char	*ft_atoi(char *nbr, char *base_from);

int	ft_base_to_int(char *new_nbr, char *base_from)
{
	int	len_new_nbr;
	int	i;
	int	j;
	int	new_nbr_int;
	int	is_negative;

	len_new_nbr = ft_len(new_nbr);
	is_negative = 0;
	if (new_nbr[0] == '-')
		is_negative = 1;
	i = is_negative;
	new_nbr_int = 0;
	while (i < len_new_nbr)
	{
		j = 0;
		while (new_nbr[i] != base_from[j])
			j++;
		new_nbr_int = new_nbr_int * ft_len(base_from) - j;
		i++;
	}
	if (!is_negative)
		new_nbr_int *= (-1);
	return (new_nbr_int);
}

char	*ft_int_to_base_add_int(int new_nbr_int, char *new_base_nbr,
				char *base_to, int len_new_base_nbr)
{
	int	len_base_to;

	len_base_to = ft_len(base_to);
	if (new_nbr_int == 0)
		new_base_nbr[0] = base_to[0];
	while (new_nbr_int < 0)
	{
		new_base_nbr[len_new_base_nbr] = base_to[- (new_nbr_int % len_base_to)];
		new_nbr_int /= len_base_to;
		len_new_base_nbr--;
	}
	return (new_base_nbr);
}

char	*ft_int_to_base(int new_nbr_int, char *base_to,
			int len_base_to, char *new_base_nbr)
{
	int	len_new_base_nbr;
	int	temp;

	len_new_base_nbr = 0;
	if (new_nbr_int < 0)
	{
		new_base_nbr[0] = '-';
		len_new_base_nbr++;
	}
	else
		new_nbr_int = -new_nbr_int;
	temp = new_nbr_int;
	if (temp == 0)
		len_new_base_nbr = 1;
	while (temp < 0)
	{
		len_new_base_nbr++;
		temp /= len_base_to;
	}
	new_base_nbr[len_new_base_nbr] = '\0';
	len_new_base_nbr--;
	new_base_nbr = ft_int_to_base_add_int(new_nbr_int, new_base_nbr,
			base_to, len_new_base_nbr);
	return (new_base_nbr);
}

int	get_base_len(int nbr, char *base_to)
{
	int	len_base_to;
	int	len_base_to_nbr;
	int	temp_nbr;

	len_base_to = ft_len(base_to);
	len_base_to_nbr = 0;
	temp_nbr = nbr;
	if (temp_nbr <= 0)
		len_base_to_nbr++;
	else
		temp_nbr *= (-1);
	while (temp_nbr != 0)
	{
		temp_nbr /= len_base_to;
		len_base_to_nbr++;
	}
	if (nbr < 0)
		len_base_to_nbr--;
	return (len_base_to_nbr);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	char	*new_nbr;
	char	*new_base_nbr;
	int		new_nbr_int;
	int		new_base_len;

	if (ft_is_base_valid(base_from) == 0 || ft_is_base_valid(base_to) == 0)
		return (NULL);
	new_nbr = ft_atoi(nbr, base_from);
	if (!new_nbr || ft_len(new_nbr) == 0
		|| (ft_len(new_nbr) == 1 && new_nbr[0] == '-'))
	{
		free(new_nbr);
		return (NULL);
	}
	new_nbr_int = ft_base_to_int(new_nbr, base_from);
	free(new_nbr);
	new_base_len = get_base_len(new_nbr_int, base_to);
	new_base_nbr = malloc(new_base_len * sizeof(char));
	new_base_nbr = ft_int_to_base(new_nbr_int, base_to,
			ft_len(base_to), new_base_nbr);
	return (new_base_nbr);
}

/*
#include <stdio.h>
int	main(void)
{
	char	*nbr;

	nbr = ft_convert_base("-CF", "0123456789ABCDEF", "0123456789");
	printf("%s", nbr);
	free(nbr);
	return (0);
}
*/
