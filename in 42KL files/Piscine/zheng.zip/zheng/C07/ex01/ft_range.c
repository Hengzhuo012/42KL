/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 12:19:36 by zheng             #+#    #+#             */
/*   Updated: 2026/06/29 13:32:27 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

/*
unsigned int	ft_set_size(unsigned int size, int min, int max)
{
	if (min >= 0 && max > 0)
		size = (unsigned int)max - (unsigned int)min;
	if (min < 0 && max >= 0)
	{
		if (min == -2147483648)
			size = (unsigned int)max + 2147483648;
		else
		{
			min *= (-1);
			size = (unsigned int)max + (unsigned int)min;
		}
	}
	if (min < 0 && max < 0)
	{
		max *= (-1);
		if (min == -214783648)
			size = 2147483648 - (unsigned int)max;
		else
		{
			min *= (-1);
			size = (unsigned int)min - (unsigned int)max;
		}
	}
	return (size);
}
*/

int	*ft_range(int min, int max)
{
	unsigned int	size;
	unsigned int	i;
	int				*array;

	if (min >= max)
		return (NULL);
	size = (unsigned int)max - (unsigned int)min;
	array = malloc(size * sizeof(int));
	i = 0;
	while (i < size)
	{
		array[i] = min + i;
		i++;
	}
	return (array);
}

/*
#include <stdio.h>
int	main(void)
{
	int	min;
	int	max;
	int	i;
	int	*array;

	min = -5;
	max = 5;
	array = ft_range(min, max);
	i = 0;
	while (i < max - min)
	{
		printf("%d ", array[i]);
		i++;
	}
	free(array);
}
*/
