/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 13:12:33 by zheng             #+#    #+#             */
/*   Updated: 2026/06/27 13:09:28 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_nbrlen(int nb)
{
	if (nb < 10)
		return (1);
	return (1 + ft_nbrlen(nb / 10));
}

void	ft_write(int nb)
{
	int		temp;
	char	to_write;

	temp = nb % 10;
	to_write = temp + '0';
	write(1, &to_write, 1);
}

int	ft_is_negative(int nb)
{
	if (nb < 0)
	{
		write(1, "-", 1);
		nb *= (-1);
	}
	return (nb);
}

void	ft_putnbr(int nb)
{
	int	j;
	int	len_nb;
	int	temp;

	if (nb == -2147483648)
		write(1, "-2147483648", 11);
	else
	{
		nb = ft_is_negative(nb);
		len_nb = ft_nbrlen(nb);
		temp = nb;
		while (len_nb > 0)
		{
			j = len_nb - 1;
			temp = nb;
			while (j > 0)
			{
				temp = temp / 10;
				j--;
			}
			ft_write(temp);
			len_nb--;
		}
	}
}

/*
int	main(void)
{
	ft_putnbr(-2147483648);
	write(1, "\n", 1);
	ft_putnbr(2147483647);
	write(1, "\n", 1);
	ft_putnbr(0);
}
*/
