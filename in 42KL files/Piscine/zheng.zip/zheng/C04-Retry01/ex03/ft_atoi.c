/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 14:10:11 by zheng             #+#    #+#             */
/*   Updated: 2026/06/27 13:07:33 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_space(char *str, int i)
{
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	return (i);
}

int	ft_is_negative(char c, int is_negative)
{
	if (c == '-')
		is_negative++;
	is_negative %= 2;
	return (is_negative);
}

long int	ft_append_digit(char c, int to_be_returned)
{
	long int	temp;
	long int	i;

	i = c - '0';
	temp = (long int)to_be_returned;
	temp *= 10;
	temp -= i;
	return (temp);
}

int	is_out_of_limit(int value, int is_negative, char c)
{
	long int	temp;

	temp = ft_append_digit(c, value);
	if (is_negative)
	{
		if (temp < -2147483648)
			return (1);
	}
	else
	{
		if (temp < -2147483647)
			return (1);
	}
	return (0);
}

int	ft_atoi(char *str)
{
	int	i;
	int	is_negative;
	int	to_be_returned;

	is_negative = 0;
	to_be_returned = 0;
	i = ft_space(str, 0);
	while (str[i] == '-' || str[i] == '+')
	{
		is_negative = ft_is_negative(str[i], is_negative);
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		if (is_out_of_limit(to_be_returned, is_negative, str[i]))
			break ;
		else
			to_be_returned = (int)ft_append_digit(str[i], to_be_returned);
		i++;
	}
	if (!is_negative)
		to_be_returned *= (-1);
	return (to_be_returned);
}

/*
#include <stdio.h>
int	main(void)
{
	char	test[] = "    ---+--+1234ab567";
	char	test2[] = "   -21474836480";
	char	test3[] = "    -+--+-21474836470";
	char	test4[] = "2147483648";

	printf("%d\n", ft_atoi(test));
	printf("%d\n", ft_atoi(test2));
	printf("%d\n", ft_atoi(test3));
	printf("%d\n", ft_atoi(test4));
}
*/
