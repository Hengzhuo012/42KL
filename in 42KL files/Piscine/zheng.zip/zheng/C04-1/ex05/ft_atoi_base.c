/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 17:41:21 by zheng             #+#    #+#             */
/*   Updated: 2026/06/26 09:30:14 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_baselen(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
		i++;
	return (i);
}

int	ft_check(char *base, int len_base)
{
	int	i;
	int	j;

	if (len_base >= 2)
	{
		i = 0;
		while (i < len_base)
		{
			j = i + 1;
			if (base[i] == '+' || base[i] == '-' || base[i] == ' '
				|| (base[i] >= 9 && base[i] <= 13))
				return (0);
			while (j < len_base)
			{
				if (base[i] == base[j])
					return (0);
				j++;
			}
			i++;
		}
		return (1);
	}
	return (0);
}

int	ft_base_to_int(char *str, char *base, int len_base, int i)
{
	int	number;
	int	check;
	int	j;

	number = 0;
	check = 1;
	while (check == 1 && str[i] != '\0')
	{
		j = 0;
		check = 0;
		while (j < len_base && check == 0)
		{
			if (str[i] == base[j])
				check = 1;
			j++;
		}
		if (check == 1)
		{
			number *= len_base;
			number += (j - 1);
		}
		i++;
	}
	return (number);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	is_negative;
	int	len_base;
	int	number;

	i = 0;
	is_negative = 0;
	len_base = ft_baselen(base);
	if (ft_check(base, len_base) == 1)
	{
		while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
			i++;
		while (str[i] == '-' || str[i] == '+')
		{
			if (str[i] == '-')
				is_negative++;
			i++;
		}
		number = ft_base_to_int(str, base, len_base, i);
		if (is_negative % 2 == 1)
			number *= (-1);
		return (number);
	}
	return (0);
}

/*
#include <stdio.h>
int	main(void)
{
	char	*base_hexa;
	char	*base_binary;
	char	*str_hexa;
	char	*str_binary;

	base_hexa = "0123456789ABCDEF";
	base_binary = "01";
	str_hexa = "10B";
	str_binary = "110101011";

	printf("%s in denary is %d\n", str_hexa, ft_atoi_base(str_hexa, base_hexa));
	printf("%s in denary is ", str_binary); 
	printf("%d\n", ft_atoi_base(str_binary, base_binary));
}
*/
