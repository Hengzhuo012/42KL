/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 13:12:33 by zheng             #+#    #+#             */
/*   Updated: 2026/06/26 09:18:25 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_nbrlen(int nb)
{
	if (nb < 10)
		return (1);
	return (1 + ft_nbrlen(nb / 10));
}

void	ft_write(int nb)
{
	int		temp;
	char	to_write;

	temp = nb % 10;
	to_write = temp + '0';
	write(1, &to_write, 1);
}

void	ft_putnbr(int nb)
{
	int	i;
	int	j;
	int	len_nb;
	int	temp;

	if (nb == -2147483648)
		write(1, "-2147483648", 11);
	else
	{
		if (nb < 0)
		{
			write(1, "-", 1);
			nb *= (-1);
		}
		len_nb = ft_nbrlen(nb);
		i = len_nb;
		temp = nb;
		while (i > 0)
		{
			j = i - 1;
			temp = nb;
			while (j > 0)
			{
				temp = temp / 10;
				j--;
			}
			ft_write(temp);
			i--;
		}
	}
}

/*
int	main(void)
{
	ft_putnbr(-1242);
}
*/
