/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 14:38:29 by zheng             #+#    #+#             */
/*   Updated: 2026/06/26 09:29:37 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_baselen(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
		i++;
	return (i);
}

int	ft_check(char *base, int len_base)
{
	int	i;
	int	j;

	if (len_base >= 2)
	{
		i = 0;
		while (i < len_base)
		{
			j = i + 1;
			if (base[i] == '+' || base[i] == '-' || base[i] == ' '
				|| (base[i] >= 9 && base[i] <= 13))
				return (0);
			while (j < len_base)
			{
				if (base[i] == base[j])
					return (0);
				j++;
			}
			i++;
		}
		return (1);
	}
	return (0);
}

int	ft_largest_digit(int nbr, char *base, int len_base)
{
	if (nbr == 0)
		return (0);
	ft_largest_digit(nbr / len_base, base, len_base);
	write(1, &base[nbr % len_base], 1);
	return (0);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	len_base;
	int	is_negative;

	len_base = ft_baselen(base);
	if (nbr < 0)
	{
		is_negative = 1;
		nbr = nbr * (-1);
	}
	else
		is_negative = 0;
	if (ft_check(base, len_base) == 1)
	{
		if (is_negative == 1)
			write(1, "-", 1);
		ft_largest_digit(nbr, base, len_base);
		write(1, "\n", 1);
	}
}

/*
int	main(void)
{
	int	nbr;
	char	*base_hexa;
	char	*base_binary;

	nbr = -267;
	base_hexa = "0123456789ABCDEF";
	base_binary = "01";
	ft_putnbr_base(nbr, base_hexa);
	ft_putnbr_base(nbr, base_binary);
}
*/
