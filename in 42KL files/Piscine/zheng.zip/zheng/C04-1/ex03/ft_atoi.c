/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 14:10:11 by zheng             #+#    #+#             */
/*   Updated: 2026/06/26 09:18:44 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_space(char *str, int i)
{
	while (str[i] == ' ' || (str[i] >= '9' && str[i] <= 13))
		i++;
	return (i);
}

int	ft_is_negative(char c, int is_negative)
{
	if (c == '-')
		is_negative++;
	return (is_negative);
}

int	ft_append_digit(char c, int to_be_returned)
{
	int	i;

	i = c - '0';
	to_be_returned = to_be_returned * 10;
	to_be_returned += i;
	return (to_be_returned);
}

int	ft_atoi(char *str)
{
	int	i;
	int	is_negative;
	int	to_be_returned;

	is_negative = 0;
	to_be_returned = 0;
	i = ft_space(str, 0);
	while (str[i] == '-' || str[i] == '+')
	{
		is_negative = ft_is_negative(str[i], is_negative);
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		to_be_returned = ft_append_digit(str[i], to_be_returned);
		i++;
	}
	if (is_negative % 2 == 1)
		to_be_returned *= (-1);
	return (to_be_returned);
}

/*
#include <stdio.h>
int	main(void)
{
	char	test[] = "    ---+--+1234ab567";

	printf("%d", ft_atoi(test));
}
*/
