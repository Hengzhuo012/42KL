git status --ignored
