/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/01 10:34:32 by zheng             #+#    #+#             */
/*   Updated: 2026/07/01 11:42:29 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Create a file named ft_stock_str.h
ADD THESE IN THE FILE
----------------------------------
#ifndef FT_STOCK_STR_H
# define FT_STOCK_STR_H

typedef struct	s_stock_str
{
	int	size;
	char	*str;
	char	*copy;
}	t_stock_str;

#endif
*/

#include "ft_stock_str.h"
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

char	*ft_strdup(char *str, int size)
{
	int		i;
	char	*dest;

	dest = malloc((size + 1) * sizeof(char));
	i = 0;
	while (str[i])
	{
		dest[i] = str[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	t_stock_str	*stocks;
	int			i;

	stocks = malloc((ac + 1) * sizeof(t_stock_str));
	if (!stocks)
		return (NULL);
	i = 0;
	while (i < ac)
	{
		stocks[i].size = ft_strlen(av[i]);
		stocks[i].str = av[i];
		stocks[i].copy = ft_strdup(av[i], stocks[i].size);
		i++;
	}
	stocks[i].str = 0;
	return (stocks);
}

/*
#include <stdio.h>
int	main(int argc, char **argv)
{
	t_stock_str	*stock;
	int		i;

	stock = ft_strs_to_tab(argc, argv);
	i = 0;
	while (i < argc)
	{
		printf("%s\n", stock[i].copy);
		free(stock[i].copy);
		i++;
	}
	free(stock);
	return (0);
}
*/
