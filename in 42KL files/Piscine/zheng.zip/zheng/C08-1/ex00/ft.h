/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/26 09:35:50 by zheng             #+#    #+#             */
/*   Updated: 2026/07/01 15:57:16 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

void	ft_putchar(char c);
void	ft_swap(int *a, int *b);
void	ft_putstr(char *str);
int		ft_strlen(char *str);
int		ft_strcmp(char *s1, char *s2);

#endif

/*
CREATE A FILE NAMED functions.c
-------------------------------
#include <unistd.h>
void	ft_putchar(char c)
{
	wrtie(1, &c, 1);
}

void	ft_swap(int *a, int *b)
{
	int	c;

	c = *a;
	*a = *b;
	*b = c;
}

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		write(1, &str[i], 1);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

int	ft_strcmp(char *s1, char *s2)
{
	unsigned char c1;
	unsigned char c2;
	int				i;

	i = 1;
	c1 = (unsigned char)s1[0];
	c2 = (unsigned char)s2[0];
	while (c1 && c2 && c1 == c2)
	{
		c1 = (unsigned char)s1[i];
		c2 = (unsigned char)s2[i];
		i++;
	}
	return (c1 - c2);
}
*/

/*
THIS IS THE main.c FILE
-----------------------
#include <unistd.h>
int	main(void)
{
	ft_putchar('h');
}
*/
