/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_abs.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/27 13:16:08 by zheng             #+#    #+#             */
/*   Updated: 2026/07/01 10:23:49 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_ABS_H
# define FT_ABS_H

# define ABS(n) (n * ((n > 0) - (n < 0)))

#endif

/*
BELOW IS THE MAIN FILE FOR TESTING

#include <stdio.h>
#include "ft_abs.h"

int	main(void)
{
	printf("%d", ABS(-5));
}
*/
