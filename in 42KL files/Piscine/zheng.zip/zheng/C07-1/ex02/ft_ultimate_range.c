/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 12:30:42 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 13:59:15 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*array;
	int	size;
	int	n;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	size = max - min;
	array = malloc(size * sizeof(int));
	if (array == NULL)
		return (-1);
	*range = array;
	n = 0;
	while (n < size)
	{
		array[n] = n + min;
		n++;
	}
	return (size);
}

/*
#include <stdio.h>
int	main(void)
{
	int	min;
	int	max;
	int	*array;
	int	size;

	min = 1;
	max = 9;
	size = ft_ultimate_range(&array, min, max);
	printf("Size: %d\n", size);
	while (size > 0)
	{
		printf("%d\n", array[size - 1]);
		size--;
	}
	free(array);
}
*/
