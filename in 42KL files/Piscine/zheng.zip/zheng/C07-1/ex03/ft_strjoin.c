/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 13:11:12 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:09:56 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_len(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	ft_total_length(char **strs, int size, char *sep)
{
	int	str_count;
	int	total_length;

	str_count = 0;
	total_length = 0;
	while (str_count < size)
	{
		total_length += ft_len(strs[str_count]);
		if (str_count != size - 1)
			total_length += ft_len(sep);
		str_count++;
	}
	return (total_length);
}

int	ft_add_sep(char *sep, int i, char *new_str)
{
	int	sep_len;
	int	char_count;

	sep_len = ft_len(sep);
	char_count = 0;
	while (char_count < sep_len)
	{
		new_str[i] = sep[char_count];
		char_count++;
		i++;
	}
	return (i);
}

int	ft_add_str(char *new_str, char **strs, int i, int str_count)
{
	int	char_count;
	int	str_len;

	char_count = 0;
	str_len = ft_len(strs[str_count]);
	while (char_count < str_len)
	{
		new_str[i] = strs[str_count][char_count];
		char_count++;
		i++;
	}
	return (i);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*new_str;
	int		str_count;
	int		i;

	if (size == 0)
	{
		new_str = malloc(1 * sizeof(char));
		return (new_str);
	}
	new_str = malloc(ft_total_length(strs, size, sep) * sizeof(char));
	str_count = 0;
	i = 0;
	while (str_count < size)
	{
		i = ft_add_str(new_str, strs, i, str_count);
		if (str_count != size - 1)
			i = ft_add_sep(sep, i, new_str);
		str_count++;
	}
	return (new_str);
}

/*
#include <stdio.h>
int	main(int argc, char **argv)
{
	char	*str_join;

	str_join = ft_strjoin(argc, argv, ", ");
	printf("%s\n", str_join);
	free(str_join);
}
*/
