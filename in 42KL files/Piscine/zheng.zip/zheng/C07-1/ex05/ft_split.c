/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/25 09:56:34 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:11:32 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	is_sep(char c, char *charset)
{
	int	i;

	i = 0;
	while (charset[i])
	{
		if (c == charset[i])
			return (1);
		i++;
	}
	return (0);
}

int	ft_arr_size(char *str, char *charset)
{
	int	i;
	int	words;

	i = 0;
	words = 0;
	while (str[i])
	{
		while (str[i] && is_sep(str[i], charset))
			i++;
		if (str[i] && !is_sep(str[i], charset))
		{
			words++;
			while (str[i] && !is_sep(str[i], charset))
				i++;
		}
	}
	return (words);
}

char	*ft_add_word(char *str, char *arr, int start, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		arr[i] = str[start + i];
		i++;
	}
	arr[i] = '\0';
	return (arr);
}

char	**ft_create_array(char *str, char *charset, char **arr)
{
	int	i;
	int	start;
	int	arr_counter;
	int	size;

	i = 0;
	arr_counter = 0;
	while (str[i] != '\0')
	{
		while (str[i] && is_sep(str[i], charset))
			i++;
		if (str[i])
		{
			start = i;
			while (str[i] && !is_sep(str[i], charset))
				i++;
			size = i - start;
			arr[arr_counter] = malloc((size + 1) * sizeof(char));
			arr[arr_counter] = ft_add_word(str, arr[arr_counter], start, size);
			arr_counter++;
		}
	}
	arr[arr_counter] = NULL;
	return (arr);
}

char	**ft_split(char *str, char *charset)
{
	char	**arr;

	arr = malloc((ft_arr_size(str, charset) + 1) * sizeof(char *));
	if (str[0] == '\0')
	{
		arr[0] = NULL;
		return (arr);
	}
	arr = ft_create_array(str, charset, arr);
	return (arr);
}

/*
#include <stdio.h>
int	main(void)
{
	char	**arr;
	int	i;

	i = 0;
	arr = ft_split("test:hello", ":eid");
	while (arr[i] != NULL)
	{
		printf("%s\n", arr[i]);
		free(arr[i]);
		i++;
	}
	free(arr);
	return (0);
}
*/
