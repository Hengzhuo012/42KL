/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 12:19:36 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 13:55:29 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*array;
	int	size;
	int	i;

	if (min >= max)
		return (NULL);
	size = max - min;
	array = malloc(size * sizeof(int));
	i = 0;
	while (i < size)
	{
		array[i] = min + i;
		i++;
	}
	return (array);
}

/*
#include <stdio.h>
int	main(void)
{
	int	min;
	int	max;
	int	i;
	int	*array;

	min = 1;
	max = 9;
	array = ft_range(min, max);
	i = 0;
	while (i < max - min)
	{
		printf("%d ", array[i]);
		i++;
	}
	free(array);
}
*/
