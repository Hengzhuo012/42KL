/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/23 11:54:38 by zheng             #+#    #+#             */
/*   Updated: 2026/06/29 10:53:22 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_len(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	return (len);
}

char	*ft_strdup(char *src)
{
	char	*new_str;
	int		src_len;
	int		i;

	src_len = ft_len(src);
	new_str = malloc((src_len + 1) * sizeof(char));
	i = 0;
	while (i <= src_len)
	{
		new_str[i] = src[i];
		i++;
	}
	return (new_str);
}

/*
#include <stdio.h>
int	main(void)
{
	char	*src;
	char	*new_str;

	src = "test\0";
	printf("Source: %s\n", src);
	new_str = ft_strdup(src);
	printf("New: %s\n", new_str);
	free(new_str);
}
*/
