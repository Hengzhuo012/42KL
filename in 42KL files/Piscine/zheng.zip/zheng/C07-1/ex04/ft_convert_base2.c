/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/25 09:48:18 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 14:10:32 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_len(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	return (len);
}

int	ft_is_base_valid(char *base)
{
	int	i;
	int	j;
	int	len;

	len = ft_len(base);
	if (len <= 1)
		return (0);
	i = 0;
	while (i < len)
	{
		j = i + 1;
		if (base[i] == '+' || base[i] == '-' || base[i] == ' '
			|| base[i] == '\f' || base[i] == '\n' || base[i] == '\r'
			|| base[i] == '\t' || base[i] == '\v')
			return (0);
		while (j < len)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

char	*ft_atoi_number(char *nbr, char *base_from,
			int nbr_counter, char *new_nbr)
{
	int	base_from_counter;
	int	new_nbr_counter;

	new_nbr_counter = 0;
	if (new_nbr[0] == '-')
		new_nbr_counter++;
	while (nbr[nbr_counter] != '\0')
	{
		base_from_counter = 0;
		while (base_from_counter < ft_len(base_from)
			&& nbr[nbr_counter] != base_from[base_from_counter])
			base_from_counter++;
		if (base_from_counter == ft_len(base_from))
			break ;
		new_nbr[new_nbr_counter] = nbr[nbr_counter];
		new_nbr_counter++;
		nbr_counter++;
	}
	new_nbr[new_nbr_counter] = '\0';
	return (new_nbr);
}

char	*ft_atoi(char *nbr, char *base_from)
{
	char	*new_nbr;
	int		nbr_counter;
	int		is_negative;
	int		new_nbr_counter;

	nbr_counter = 0;
	is_negative = 0;
	new_nbr_counter = 0;
	new_nbr = malloc((ft_len(nbr) + 1) * sizeof(char));
	while (nbr[nbr_counter] == ' '
		|| (nbr[nbr_counter] >= '9' && nbr[nbr_counter] <= 13))
		nbr_counter++;
	while (nbr[nbr_counter] == '+' || nbr[nbr_counter] == '-')
	{
		if (nbr[nbr_counter] == '-')
			is_negative++;
		nbr_counter++;
	}
	if (is_negative % 2 != 0)
	{
		new_nbr[new_nbr_counter] = '-';
		new_nbr_counter++;
	}
	new_nbr = ft_atoi_number(nbr, base_from, nbr_counter, new_nbr);
	return (new_nbr);
}
