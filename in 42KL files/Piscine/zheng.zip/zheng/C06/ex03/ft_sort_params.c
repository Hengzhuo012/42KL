/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/22 13:22:09 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 15:32:49 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/*
compare s1 and s2
return > 0 if asc of s1 > s2 else return < 0
*/

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0')
		i++;
	return (s1[i] - s2[i]);
}

char	**ft_sort(int argc, char **argv)
{
	int		i;
	int		swap_check;
	int		len;
	char	*temp;

	swap_check = 1;
	len = argc - 1;
	while (swap_check == 1)
	{
		swap_check = 0;
		i = 1;
		while (i < len)
		{
			if (ft_strcmp(argv[i], argv[i + 1]) > 0)
			{
				temp = argv[i];
				argv[i] = argv[i + 1];
				argv[i + 1] = temp;
				swap_check = 1;
			}
			i++;
		}
		len--;
	}
	return (argv);
}

void	ft_print(int argc, char **argv)
{
	int	i;
	int	j;

	i = 1;
	while (i < argc)
	{
		j = 0;
		while (argv[i][j])
		{
			write(1, &argv[i][j], 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	char	**temp;

	if (argc >= 2)
	{
		temp = argv;
		temp = ft_sort(argc, temp);
		ft_print(argc, temp);
	}
	return (0);
}
