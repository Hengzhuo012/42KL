/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 18:13:11 by zheng             #+#    #+#             */
/*   Updated: 2026/06/20 11:38:20 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_find_next_prime(int nb)
{
	int	i;
	int	check;
	int	next_prime;

	if (nb <= 2)
		return (2);
	check = 0;
	next_prime = nb;
	while (check == 0)
	{
		check = 1;
		i = 2;
		while (i < next_prime)
		{
			if (next_prime % i == 0)
				check = 0;
			i++;
		}
		if (check == 0)
			next_prime++;
	}
	return (next_prime);
}

/*
int	main(void)
{
	int	n1;
	int	n2;

	n1 = 1;
	n2 = 95;
	printf("%d next prime is %d\n", n1, ft_find_next_prime(n1));
        printf("%d next prime is %d\n", n2, ft_find_next_prime(n2));
}
*/
