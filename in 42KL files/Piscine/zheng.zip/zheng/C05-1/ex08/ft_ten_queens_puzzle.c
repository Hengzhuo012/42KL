/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/20 11:38:42 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 13:14:50 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_check(char *str)
{
	int	i;
	int	j;

	i = 0;
	while (i++ < 10)
	{
		j = i + 1;
		while (j++ < 10)
		{
			if (str[i] == str[j] || str[i] + j == str[j]
				|| str[i] - j == str[j])
				return (0);
		}
	}
	return (1);
}

char	*ft_create_solution(char *str)
{
	int		i;

	i = 9;
	while (str[i] == '9')
		i--;
	if (i == -1)
		return ("0");
	if (ft_check(str))
		return (str);
	i = 9;
	while (str[i] == 9)
		str[i--] = 0;
	str[i] += 1;
	return (ft_create_solution(str));
}

#include <stdio.h>
int	ft_ten_queens_puzzle(void)
{
	char	*str;
	int		sol;
	int		i;
	int		is_last;

	str = "0257948136";
	sol = 0;
	is_last = 1;
	while (is_last)
	{
		i = 0;
		while (str[i] == '9')
			i++;
		if (i != 10)
		{
			is_last = 0;
			if (ft_create_solution(str) != str)
			{
				str = ft_create_solution(str);
				sol++;
				write(1, str, 10);
				i = 9;
				while (str[i] == 9)
					str[i--] = 0;
				str[i] += 1;
			}
		}
	}
	return (sol);
}

int	main(void)
{
	int	no_sol;

	no_sol = ft_ten_queens_puzzle();
	printf("There is %d of solutions", no_sol);
}
