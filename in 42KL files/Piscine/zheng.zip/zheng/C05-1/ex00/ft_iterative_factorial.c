/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:43:39 by zheng             #+#    #+#             */
/*   Updated: 2026/06/28 11:23:38 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_iterative_factorial(int nb)
{
	int	i;
	int	number;

	number = 1;
	if (nb < 0)
		return (0);
	else
	{
		if (nb >= 0)
		{
			i = nb;
			while (i >= 1)
			{
				number *= i;
				i--;
			}
			return (number);
		}
	}
	return (0);
}

/*
int	main(void)
{
	int	n;

	n = 5;
	printf("factorial of %d is %d", n, ft_iterative_factorial(n));
}
*/
