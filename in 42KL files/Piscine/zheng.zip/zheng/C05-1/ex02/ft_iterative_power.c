/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/19 12:54:57 by zheng             #+#    #+#             */
/*   Updated: 2026/06/19 17:35:10 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	number;

	number = 1;
	if (nb == 0)
		return (1);
	else
	{
		i = 1;
		while (i <= power)
		{
			number *= nb;
			i++;
		}
		return (number);
	}
}

/*
int	main(void)
{
	int	n;
	int	p;

	n = 5;
	p = 3;
	printf("%d ^ %d = %d", n, p, ft_iterative_power(n, p));
}
*/
