/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 11:10:49 by zheng             #+#    #+#             */
/*   Updated: 2026/06/24 18:33:07 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				dest_len;
	int				src_len;
	unsigned int	i;

	dest_len = ft_strlen(dest);
	src_len = ft_strlen(src);
	i = dest_len;
	while (i <= dest_len + src_len - 1 && i - dest_len <= nb - 1)
	{
		dest[i] = src[i - dest_len];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/*
#include <stdio.h>
#include <string.h>
int	main(void)
{
	char dest[] = "Test\0\0\0\0\0\0\0";
	char dest2[] = "Test\0\0\0\0\0\0\0";
	char src[] = "randoms";

	printf("Before: %s\n", dest);
	printf("After: %s", ft_strncat(dest, src, 5));
	printf("Before: %s\n", dest2);
	printf("After: %s", strncat(dest2, src, 5));
}
*/
