/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zheng <zheng@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/18 12:02:36 by zheng             #+#    #+#             */
/*   Updated: 2026/06/24 18:32:50 by zheng            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;
	int	len_to_find;
	int	len_str;

	i = 0;
	j = 0;
	len_to_find = ft_strlen(to_find);
	len_str = ft_strlen(str);
	while (str[i] != '\0')
	{
		j = 0;
		while (str[i + j] == to_find[j])
		{
			if (j == len_to_find - 1)
				return (&str[i]);
			j++;
		}
		i++;
	}
	return (0);
}

/*
#include <stdio.h>
int	main(void)
{
	char	str[] = "I am great and greedy";
	char	to_find[] = "gre";

	printf("%s", ft_strstr(str, to_find));
}
*/
